#include <iostream>
using namespace std;
int main(int argc, char const *argv[]) {
    int cases;
    std::cin >> cases;
  return 0;
}
